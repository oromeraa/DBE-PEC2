<?php

declare(strict_types=1);

namespace Drupal\Tests\migrate_drupal\Functional;

use Drupal\Tests\system\Functional\Module\GenericModuleTestBase;

/**
 * Generic module test for migrate_drupal.
 *
 * @group migrate_drupal
 */
class GenericTest extends GenericModuleTestBase {}
