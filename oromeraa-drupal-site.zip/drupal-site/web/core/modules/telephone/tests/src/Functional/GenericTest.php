<?php

declare(strict_types=1);

namespace Drupal\Tests\telephone\Functional;

use Drupal\Tests\system\Functional\Module\GenericModuleTestBase;

/**
 * Generic module test for telephone.
 *
 * @group telephone
 */
class GenericTest extends GenericModuleTestBase {}
