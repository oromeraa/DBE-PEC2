<?php

declare(strict_types=1);

namespace Drupal\Tests\migrate\Functional;

use Drupal\Tests\system\Functional\Module\GenericModuleTestBase;

/**
 * Generic module test for migrate.
 *
 * @group migrate
 */
class GenericTest extends GenericModuleTestBase {}
